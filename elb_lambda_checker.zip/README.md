# Amazon elb lambda checker

After upload zip to amazon lambda, set tokens and channels for TELEGRAM and SLACK

For, add custom python package see link:
https://aws.amazon.com/ru/premiumsupport/knowledge-center/build-python-lambda-deployment-package/
