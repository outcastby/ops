import websocket
import time
import json
from botocore.vendored import requests

TELEGRAM_TOKEN = '<TELEGRAM_TOKEN>'
TELEGRAM_CHAT_ID = '<TELEGRAM_CHAT_ID>'
TELEGRAM_URL = "https://api.telegram.org/bot{}/sendMessage".format(TELEGRAM_TOKEN)
SLACK_TOKEN = '<SLACK_TOKEN>'
SLACK_CHANNEL = '<SLACK_CHANNEL>'
SLACK_URL = 'https://slack.com/api/chat.postMessage?pretty=1'

def send_message(text):
    # Send tg notification
    requests.post(TELEGRAM_URL, data={'chat_id': TELEGRAM_CHAT_ID, 'text': text})

    # Send slack notification
    headers = {'Content-Type': 'application/json', 'Authorization': "Bearer {}".format(SLACK_TOKEN)}
    requests.post(SLACK_URL, data=json.dumps({'channel': SLACK_CHANNEL, 'text': text}), headers=headers)

def check_errors(count_errors, attempts = 0):
    attempts = attempts + 1
    try:
        ws = websocket.WebSocket()
        ws.connect("wss://arcade.prod.server-planet-gold-rush.com/socket/websocket?access_key=qwqwqwqwqw")
        ws.close()
    except:
        count_errors = count_errors + 1

    if attempts == 6:
        print("Count Errors in connection - {}".format(count_errors))
        if count_errors > 1:
            send_message("\u2757\u2757\u2757 Error in load balancer.\n WebSocket connection is not available")
    else:
        time.sleep(10)
        check_errors(count_errors, attempts)

def lambda_handler(event, context):
    check_errors(0)
    # TODO implement
    return {
        'statusCode': 200

    }

